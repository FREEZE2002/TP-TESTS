class LangueStub:
    def dire_bonjour(self, periode_journee):
        return ""

    def bien_dit(self):
        return ""

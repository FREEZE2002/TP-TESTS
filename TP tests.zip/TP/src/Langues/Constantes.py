class Constantes:
    class Francais:
        BONSOIR = "Bonsoir"
        AU_REVOIR = "Au revoir"
        BONJOUR = "Bonjour"
        BIEN_DIT = "Bien dit"

    class Anglais:
        GOOD_MORNING = "Good Morning"
        GOOD_AFTERNOON = "Good Afternoon"
        GOOD_NIGHT = "Good Night"
        WELL_DONE = "Well Done"
        HELLO = "Hello"
        GOOD_EVENING = "Good Evening"